<template>
    <div class="style">
        <img src="@/material/logo_huateng.png" class="style1">
        <div class="text-group">
            <h3>关于我们>></h3>
            <h3>联系我们>></h3>
        </div>
    </div>
</template>

<script>

</script>

<style scoped>
.style {
    width: 100%;
    height: 80px;
    margin-left: 50px;
    margin-top: 20px;
    display: flex;
    align-items: center;
    justify-content: space-between;

}

h3 {
    /* border:3px solid burlywood; */
    /* box-sizing: border-box; */
    font-family: "微软雅黑";
    color: white;
    font-size: 25px;

}

.text-group {
    display: flex;
    gap: 50px;
    margin-right: 300px;
}
</style>