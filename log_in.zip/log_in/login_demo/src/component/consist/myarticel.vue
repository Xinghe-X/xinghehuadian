<template>
    <h3 class="style1">你自山河林间来</h3>
    <h3 class="style2">惊鸿一现百花开</h3>
</template>

<script>

</script>
<style>
@font-face {
    font-family: "myziti2";
    src: url("@/material/ziti2.ttf") format("truetype");
}
</style>



<style scoped>
.style1 {
    text-align: left;
    color: white;
    margin-top: 200px;
    margin-left: 200px;
    font-size: 50px;
    font-family: "myziti2";
}

.style2 {
    text-align: right;
    color: white;
    margin-right: 200px;
    font-size: 50px;
    font-family: "myziti2";
}
</style>